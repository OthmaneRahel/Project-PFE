{/* <nav class="navbar navbar-expand-lg">
            <div class="container">
                <Link className="navbar-brand" to="/">
                    <h3 className='text text-primary px-5'>  <img src='logopfe.jpg' width={'60px'} /> AGENCE DE VOYAGE</h3>
                </Link>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav justify-content-end">
                    <li class="nav-item">
                        <Link className="nav-link text-dark " to="/acceuil">
                            <i class="fa-solid fa-house"></i> Accueil
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link className="nav-link  text-dark" to="/listeVoyage">
                            <i class="fa-solid fa-person-walking-luggage"></i> Voyage organisé
                        </Link>
                    </li>
                    <li class="nav-item">
                        <Link className="nav-link" to="/haj-omra">
                            <i class="fa-solid fa-kaaba"></i> Haj et Omra
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link  text-dark" to="/listVol">
                            <i class="fa-solid fa-plane-departure"></i> Vol
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link text-dark" to="/Contact">
                            <i class="fa-solid fa-id-badge"></i> Contact
                        </Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link text-dark">
                            <i class="bi bi-brightness-high-fill" id="toggleDark"></i>
                        </Link>
                    </li>
                </ul>
                </div>
            </div>
            </nav> */}