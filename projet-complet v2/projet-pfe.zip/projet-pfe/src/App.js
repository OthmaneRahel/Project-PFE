import './App.css';
import NavBar from './components/project_pfe/Acceuil';
import Accueil from './components/project_pfe/imageAcceuil';
import {Route, BrowserRouter as Router, Routes, Link } from 'react-router-dom';
import VoyageOrg from './components/project_pfe/VoyageOrganisee';
import Aff from './components/project_pfe/voyageUniq';
import Contact from './components/project_pfe/contact';
import Footer from './components/project_pfe/footer';
import HajOrg from './components/project_pfe/HajOrganise';
import HajUnique from './components/project_pfe/HajUnique';
import Reservation_Voyage from './components/project_pfe/Reservation_Voyage';
import VolOrganisee from './components/project_pfe/VolOrganisee';
import AjouterVoyage from './components/project_pfe/AjouterVoyage';
import AjouterVols from './components/project_pfe/AjouterVol';
import VolUnique from './components/project_pfe/VolUnique';
import Reservation_Vol from './components/project_pfe/Reservation_Vol';
import ConfirmationReservationVoyage from './components/project_pfe/Confimation_Reservation_voyage';
import ConfirmationReservationVol from './components/project_pfe/Confimation_Reservation_vol';
import AjtHaj from './components/project_pfe/AjouterHaj';
import Sidebar from './components/project_pfe/SideBarAdmin';
import LoginPage from './components/project_pfe/LoginPage';
import Logout from './components/project_pfe/logout';
import AfficherlistDemande from './components/project_pfe/AfficherListDemande';
function App() {
    
  return (
    <div className="App">
         <Router>
            <Routes>
                <Route path='/' element={<Accueil/>}/>
                <Route path="/acceuil" element={<Accueil/>}  />
                <Route path="/listeVoyage" element={<VoyageOrg/>} />
                <Route path='/voyage-sel/:id' element={<Aff/>}/> 
                <Route path='/reservation' element={<Reservation_Voyage/>}/>
                <Route path='/haj-sel/:id' element={<HajUnique/>}/>
                <Route path="/Contact" element={<Contact/>}/>
                <Route path="/haj-omra" element={<HajOrg/>}/>
                <Route path="/listVol" element={<VolOrganisee/>}/>
                <Route path="/vol-sel/:id" element={<VolUnique/>}/>
                <Route path="/ajouterV" element={<AjouterVoyage/>}/>
                <Route path="/ajouterVol" element={<AjouterVols/>}/>
                <Route path="/reservation-vol" element={<Reservation_Vol/>} />
                <Route path="/reserveVoyages" element={<ConfirmationReservationVoyage/>} />
                <Route path="/reserveVol" element={<ConfirmationReservationVol/>}/>
                <Route path="/ajouterHaj" element={<AjtHaj/>}/>
                <Route path="/admin" element={<Sidebar/>}/>
                <Route path="/login" element={<LoginPage/>}/>
                <Route path="/logout" element={<Logout/>}/>
                <Route path="/AfficherListDemandes" element={<AfficherlistDemande/>}/>
            </Routes>
         </Router>
          <Footer/>
    </div>
  );
}

export default App;
