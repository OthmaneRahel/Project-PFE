import axios from "axios";
import React, { useEffect, useState } from "react";
export default function AfficherlistDemande(){
    const [listDataDemandes,setDataDemandes]=useState([])
    useEffect(()=>{
        axios.get('http://127.0.0.1:8000/api/Afficher-list-demande').then((res)=>{
            setDataDemandes(res.data)
        })
    },[])
    return <>
    <table className="table table-hover">
        <thead>
            <th>Nom et Prénom</th>
            <th>Adresse-Email</th>
            <th>Nom de la Demande</th>
            <th>Demande</th>
            <th>Autre demande</th>

        </thead>
        <tbody>
            {
                listDataDemandes.map((e)=>{
                    console.log(listDataDemandes)
                    return <tr>
                        <td>{e.Nom}{' '}{e.Prenom}</td>
                        <td>{e.adresseEmail}</td>
                        <td>{e.NomDemande}</td>
                        <td>{e.demande}</td>
                        {
                            e.autre_demande !== null ?
                            <td>{e.autre_demande}</td>
                            : <td>Aucune Autre Demande</td>
                        }
                    </tr>
                })
            }
        </tbody>
    </table>
    </>
}