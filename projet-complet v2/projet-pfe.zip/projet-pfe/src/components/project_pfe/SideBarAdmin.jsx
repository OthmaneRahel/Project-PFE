import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Logout from './logout';
import axios from 'axios';

export default function Sidebar() {
  // const [user, setUser] = useState(null);
  // const [loading, setLoading] = useState(true);

  // useEffect(() => {
  //   const token = localStorage.getItem('token');
  //   if (token) {
  //     axios.get('http://127.0.0.1:8000/api/nom-user', {
  //       headers: {
  //         'Authorization': `Bearer ${token}`
  //       }
  //     })
  //     .then(response => {
  //       setUser(response.data);
  //       setLoading(false);
  //     })
  //     .catch(error => {
  //       console.error('Error fetching user name:', error);
  //       setLoading(false);
  //     });
  //   }
  // }, []);


  // useEffect(() => {
  //   const token = localStorage.getItem('token');
  //   if (token) {
  //     axios.get('http://127.0.0.1:8000/api/nom-user', {
  //       headers: {
  //         'Authorization': `Bearer ${token}`
  //       }
  //     })
  //     .then(response => {
  //       console.log(response.data); // Ajoutez ceci pour voir la réponse
  //       setUser(response.data);
  //       setLoading(false);
  //     })
  //     .catch(error => {
  //       console.error('Error fetching user name:', error);
  //       setLoading(false);
  //     });
  //   }
  // }, []);
  
  const handleLogout = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://127.0.0.1:8000/api/logout', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      localStorage.removeItem('token');
      window.location.href = '/login';
    } catch (error) {
      console.error('There was an error logging out!', error);
    }
  };
  useEffect(() => {
    const handleClick = () => {
      document.querySelector("#sidebar").classList.toggle("expand");
    };

    const hamBurger = document.querySelector(".toggle-btn");
    if (hamBurger) {
      hamBurger.addEventListener("click", handleClick);
    }
    return () => {
      if (hamBurger) {
        hamBurger.removeEventListener("click", handleClick);
      }
    };
  }, []);

  // if (loading) {
  //   return <div className='text-center' style={{ fontSize: '35px' }}>Loading...</div>;
  // }

  return (
    <div className="wrapper">
      <aside id="sidebar">
        <div className="d-flex">
          <button className="toggle-btn" type="button">
            <i className="bi bi-list"></i>
          </button>
          <div className="sidebar-logo">
            <a href="#">Nezaha Voyages</a>
          </div>
        </div>
        <ul className="sidebar-nav">
          <li className="sidebar-item">
            <Link to={'/ajouterV'} className="sidebar-link">
              <i className="bi bi-building"></i>
              <span style={{ fontSize: '21px' }}>Liste de reservation</span>
            </Link>
          </li>
          <li className="sidebar-item">
            <Link to={''} className="sidebar-link">
              <i className="bi bi-building"></i>
              <span style={{ fontSize: '21px' }}>Liste Demandes</span>
            </Link>
          </li>
          <li className="sidebar-item">
            <Link to={''} className="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#auth" aria-expanded="false" aria-controls="auth">
              <i className="bi bi-people"></i>
              <span style={{ fontSize: '21px' }}>Ajouter</span>
            </Link>
            <ul id="auth" className="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
              <li className="sidebar-item">
                <a href="#" className="sidebar-link"><i className="bi bi-person-plus"></i> Ajouter Haj</a>
              </li>
              <li className="sidebar-item">
                <a href="#" className="sidebar-link"><i className="bi bi-person-plus"></i> Ajouter Voyage</a>
              </li>
              <li className="sidebar-item">
                <a href="#" className="sidebar-link"><i className="bi bi-person-plus"></i> Ajouter Vol</a>
              </li>
              <li className="sidebar-item">
                <a href="#" className="sidebar-link"><i className="bi bi-person-plus"></i> Ajouter Voyage disponible</a>
              </li>
              <li className="sidebar-item">
                <a href="#" className="sidebar-link"><i className="bi bi-person-plus"></i> Ajouter Vol disponible</a>
              </li>
            </ul>
          </li>
          <li className="sidebar-item">
            <a href="#" className="sidebar-link">
              <i className="bi bi-bell"></i>
              <span style={{ fontSize: '21px' }}>Notification</span>
            </a>
          </li>
        </ul>
        <div className="sidebar-footer">
          <a className="sidebar-link text-white" onClick={handleLogout}><i class="bi bi-box-arrow-left"></i> 
            <span style={{ fontSize: '21px' }}>Logout</span>
          </a>
        </div>
      </aside>
      <div className="main p-3">
        <div className="text-center">

        </div>
      </div>
    </div>
  );
}
