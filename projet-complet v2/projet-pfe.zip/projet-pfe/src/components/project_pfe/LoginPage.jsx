import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
    const [error, setError] = useState(null);
    const [token, setToken] = useState(null);
    const [errors, setErrors] = useState({});
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate()
    const handleLogin = async (e) => {
        e.preventDefault();
        try {
          const response = await axios.post('http://127.0.0.1:8000/api/login', {
            email: email,
            password: password,
          });
          console.log(response.data)
          if (response.data.success === false) {
            setError('Votre infos sont incorrectes , Veuillez Ressayer plus tard');
          } else {
            setToken(response.data);
            setError(null);
            setErrors({})
            localStorage.setItem('token', response.data);
            navigate('/admin')
          }
        } catch (error) {
            setErrors(error.response.data.errors)
            setError('Votre infos sont incorrectes , Veuillez Ressayer plus tard');
        }
      };
    return (
        <div className="row">
            <div className="col-lg-6 imageAc">
                <img src="/images/S3.png" width={'100%'} alt="Logo"/>
            </div>
            <div className="col-lg-6">
                <div className="agenceWelcome">
                    <img src="/images/logopfe.png" alt="Logo"/>
                    <span>Nezaha Voyages Admistration</span>
                </div>
                <div className="content" >
                    <h3><span><i className="bi bi-person"></i></span> Login to Nezaha Voyages !</h3>
                    <form onSubmit={handleLogin}>
                        <label htmlFor="">Email :</label>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text"><i className="bi bi-envelope"></i></span>
                            </div>
                            <input type="email" className="form-control" placeholder="Email" name="email" onChange={(e) => setEmail(e.target.value)} />
                        </div>
                        {errors && errors.email && (
                            <p className="text-danger">{errors.email}</p>
                        )}
                        <label htmlFor="">Password :</label>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text"><i className="bi bi-key"></i></span>
                            </div>
                            <input type="password" className="form-control" placeholder="Password" name="password" onChange={(e) => setPassword(e.target.value)} />
                        </div>
                        {errors && errors.password && (
                            <p className="text-danger">{errors.password}</p>
                        )}
                        {error && <p style={{ color: 'red' }}>{error}</p>}
                        <div className="d-grid">
                            <input className="btn btn-success btn-block" type="submit" value={'Se connecter'} />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
