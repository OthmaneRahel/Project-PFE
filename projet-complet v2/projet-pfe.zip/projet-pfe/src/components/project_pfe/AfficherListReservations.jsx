import axios from "axios";
import React, { useEffect, useState } from "react";
export default function AfficherListReservations(){
    const [dataReservation , setdataReservation] = useState([])
    useEffect(()=>{
        axios.get('http://127.0.0.1:8000/api/AfficherListReservation').then((res)=>{
            setdataReservation(res.data)
        })
    },[])
    return <>
        <table className="table table-striped">
            <thead>
                
            </thead>
            <tbody>
                {
                    dataReservation.map((e)=>{
                        return <tr>
                            <td>{e.idReservation}</td>
                        </tr>
                    })
                }
            </tbody>
        </table>
    </>
}