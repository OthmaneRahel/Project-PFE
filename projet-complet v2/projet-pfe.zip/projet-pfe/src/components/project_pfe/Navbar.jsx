import React from "react";
import { Link } from "react-router-dom";
export default function Navbar(){
    return <nav className="navbar navbar-expand-lg navbar-light text-dark" >
    <a className="navbar-brand" href="/acceuil"><img src="/images/logopfe.png" width={'80px'}/><b className='nomVyg'>Nezaha Voyages</b></a>
    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style={{marginRight:'24px'}}>
    <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
       <ul className="navbar-nav ml-auto">
          <li className="nav-item">
                <Link className="nav-link" to="/acceuil">
                    <i class="fa-solid fa-house"></i> Accueil
                </Link>
          </li>
          <li className="nav-item">
                <Link className="nav-link text-dark" to="/listeVoyage">
                    <i class="fa-solid fa-person-walking-luggage"></i> Voyage organisé
                </Link>
          </li>
          <li className="nav-item">
                <Link className="nav-link text-dark" to="/haj-omra">
                    <i class="fa-solid fa-kaaba"></i> Haj et Omra
                </Link>
          </li>
          <li className="nav-item">
             <Link className="nav-link" to="/listVol">
                 <i class="fa-solid fa-plane-departure"></i> Vol
             </Link>
          </li>
          <li className="nav-item">
             <Link className="nav-link" to="/Contact">
                 <i class="fa-solid fa-id-badge"></i> Contact Us
             </Link>
          </li>
       </ul>
       <form className="form-inline my-2 my-lg-0">
          <div className="login_bt">
             <ul>
                <li><a href="#"><span className="user_icon"></span></a></li>
                <li><a href="#"></a></li>
             </ul>
          </div>
       </form>
    </div>
</nav>
}