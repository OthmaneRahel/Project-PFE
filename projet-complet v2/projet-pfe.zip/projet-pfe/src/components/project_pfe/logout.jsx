// import React from 'react';
// import axios from 'axios';

// function Logout() {
  

//   return (
//     <button onClick={handleLogout} style={{color:'black'}}>Logout</button>
//   );
// }

// export default Logout;
