import React, { useState } from "react";
import axios from "axios";

export default function LoginPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://127.0.0.1:8000/api/login", { email, password });
            console.log("Success:", response.data);
            // Réinitialiser les champs du formulaire après une soumission réussie
            setEmail("");
            setPassword("");
            // Réinitialiser les erreurs de validation
            setErrors({});
        } catch (error) {
            if (error.response && error.response.status === 422) {
                setErrors(error.response.data.errors);
            } else {
                console.error("Error:", error);
            }
        }
    };

    return (
        <div className="row">
            <div className="col-lg-6 imageAc">
                <img src="/images/S3.png" width={"100%"} />
            </div>
            <div className="col-lg-6">
                <div className="agenceWelcome">
                    <img src="/images/logopfe.png" alt="logo" />
                    <span>Nezaha Voyages Administration</span>
                </div>
                <div className="content">
                    <h3>
                        <span>
                            <i className="bi bi-person"></i>
                        </span>{" "}
                        Login Now !
                    </h3>
                    <form onSubmit={handleSubmit}>
                        <label htmlFor="email">Email :</label>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text">
                                    <i className="bi bi-envelope"></i>
                                </span>
                            </div>
                            <input
                                type="text"
                                className="form-control"
                                id="email"
                                placeholder="Email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </div>
                        {errors && errors.email && (
                            <p className="text-danger">{errors.email[0]}</p>
                        )}
                        <label htmlFor="password">Password :</label>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text">
                                    <i className="bi bi-key"></i>
                                </span>
                            </div>
                            <input
                                type="password"
                                className="form-control"
                                id="password"
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>
                        {errors && errors.password && (
                            <p className="text-danger">{errors.password[0]}</p>
                        )}
                        <div className="d-grid">
                            <button
                                type="submit"
                                className="btn btn-success btn-block"
                            >
                                <i className="bi bi-box-arrow-in-right"></i>{" "}
                                Se connecter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}
