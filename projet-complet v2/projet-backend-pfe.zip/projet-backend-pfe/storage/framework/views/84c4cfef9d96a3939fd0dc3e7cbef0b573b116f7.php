<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route('ajouterV')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="nom Ville" name="nomVille">
        <input type="file" name="image" placeholder="image"/>
        <input type="text" placeholder="prix" name="prix"/>
        <input type="date" placeholder="Date depart" name="date_depart"/>
        <input type="date" placeholder="Date arrivee" name="date_arrivee"/>
        <input type="text" placeholder="description" name="description"/>
        
        <input type="submit" value="ok">
    </form>
</body>
</html><?php /**PATH C:\Users\J.P.M\projet-backend-pfe\resources\views/AjouterVoyage.blade.php ENDPATH**/ ?>